# Go Shopping App Framework
A Framework for Online Shopping Application

A simple framework for Online Shopping Application to represent Prime Accounts and Non-Prime (Normal)Accounts. 
